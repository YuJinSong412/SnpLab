# solidity-token-example
A simple smart-contract example of the basic use of tokens (ERC-20, ERC-721).

Visit https://remix.ethereum.org/ and try this.
